Category.create(name: "Smartphones")
Category.create(name: "Shoes")
Category.create(name: "Accesories")
